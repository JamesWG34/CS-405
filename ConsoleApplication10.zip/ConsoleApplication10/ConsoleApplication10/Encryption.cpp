// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // TODO: student need to change the next line from output[i] = source[i]
        // transform each character based on an xor of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];  // XOR logic
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text = "John Q. Smith\nThis is my test string";

    // TODO: implement loading the file into a string
    std::ifstream infile(filename);
    std::string line;
    file_text.clear(); // clear default string

    if (!infile)
    {
        std::cerr << "Error opening file: " << filename << std::endl;
        return "";
    }

    while (std::getline(infile, line))
    {
        file_text += line + "\n";
    }

    infile.close();

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    {
        // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    //  TODO: implement file saving
    //  file format
    //  Line 1: student name
    //  Line 2: timestamp (yyyy-mm-dd)
    //  Line 3: key used
    //  Line 4+: data

    std::ofstream outfile(filename);
    if (!outfile)
    {
        std::cerr << "Error writing to file: " << filename << std::endl;
        return;
    }

    // get current time using secure version
    std::time_t t = std::time(nullptr);
    std::tm now = {};
    localtime_s(&now, &t);  // secure version for Visual Studio

    char date[11];
    std::strftime(date, sizeof(date), "%Y-%m-%d", &now);

    outfile << student_name << "\n";
    outfile << date << "\n";
    outfile << key << "\n";
    outfile << data;

    outfile.close();
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    std::string key = "mySecretKey";
    std::string input_filename = "inputdatafile.txt";
    std::string encrypted_filename = "encrypted.txt";
    std::string decrypted_filename = "decrypted.txt";

    // Step 1: Load the original data
    std::string original_data = read_file(input_filename);
    if (original_data.empty()) {
        std::cerr << "Failed to read input file. Exiting.\n";
        return 1;
    }

    // Step 2: Extract student name
    std::string student_name = get_student_name(original_data);

    // Step 3: Encrypt the data
    std::string encrypted = encrypt_decrypt(original_data, key);
    save_data_file(encrypted_filename, student_name, key, encrypted);

    // Step 4: Decrypt the encrypted data
    std::string decrypted = encrypt_decrypt(encrypted, key);
    save_data_file(decrypted_filename, student_name, key, decrypted);

    std::cout << "Encryption and Decryption complete.\n";
    return 0;
}
